#!/bin/bash
as86 -O boot-b.s -o boot-b.o
ld86 -d boot-b.o -o boot-b.bin
chmod a-x boot-b.bin

dd if=boot-b.bin of=/dev/fd0
dd if=koi8-8x16.fnt of=/dev/fd0 seek=1
