#!/bin/bash
as86 -O boot-a.s -o boot-a.o
ld86 -d boot-a.o -o boot-a.bin
chmod a-x boot-a.bin

dd if=boot-a.bin of=/dev/fd0
dd if=koi8-8x16.fnt of=/dev/fd0 seek=1
