<!DOCTYPE html>
<html>
    <head>
        <title>Example Title</title>
    </head>
    <body>
        <p>
            Hello. Today is <?= date('l \t\h\e jS') ?>.
        </p>
    </body>
</html>
